import React, { useCallback, useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { Upload, CheckCircle } from 'lucide-react';
import * as XLSX from 'xlsx';
import { cn } from '../lib/utils';
import type { Task } from '../types';
import { differenceInCalendarDays } from 'date-fns';

export function FileUpload() {
    const inputRef = React.useRef<HTMLInputElement>(null);
    const {
        addTasks,
        columnMapping,
        setRawHeaders,
        setMappingModalOpen,
        tasks
    } = useStore();
    const [pendingFiles, setPendingFiles] = useState<File[]>([]);

    // Auto-process pending files when mapping is available
    useEffect(() => {
        if (columnMapping && pendingFiles.length > 0) {
            // Process all pending files
            pendingFiles.forEach(file => processFile(file));
            setPendingFiles([]);
        }
    }, [columnMapping, pendingFiles]);

    const processFile = (file: File) => {
        // If we don't have a mapping yet, queue it.
        // CHECK: If we already have pending files, we just add to them?
        // Actually, we need to check columnMapping inside the function or before calling it.
        // But processFile is called by onDrop/onChange.

        // Let's modify the flow slightly: 
        // 1. Read the file to get headers. 
        // 2. If no mapping, set headers and queue THIS file (and any others).
        // The issue is reading is async.

        const reader = new FileReader();
        reader.onload = (e) => {
            const data = new Uint8Array(e.target?.result as ArrayBuffer);
            const workbook = XLSX.read(data, { type: 'array', cellDates: true }); // cellDates true to get Date objects
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

            if (jsonData.length === 0) return;

            // Smart Header Detection
            // We scan the first 20 rows to find the one that looks like a header row
            // Criteria: Contains "Task", "Tarea", "Descripcion" OR "Fecha"
            let headerRowIndex = 0;
            let detectedHeaders: string[] = [];

            for (let i = 0; i < Math.min(jsonData.length, 20); i++) {
                const row = jsonData[i] as any[];
                if (!row) continue;
                // Convert row to string array for checking
                const rowValues = row.map(cell => String(cell).toUpperCase());

                const hasTask = rowValues.some(v => v.includes('TAREA') || v.includes('TASK') || v.includes('DESCRIPCION') || v.includes('ACTIVIDAD') || v.includes('NOMBRE'));
                const hasDate = rowValues.some(v => v.includes('FECHA') || v.includes('DATE') || v.includes('INICIO') || v.includes('START'));

                if (hasTask && hasDate) {
                    headerRowIndex = i;
                    detectedHeaders = rowValues; // Use the uppercase normalized headers or original? Let's use original for display
                    // Actually, let's use the original values from row but strictly as strings
                    detectedHeaders = (jsonData[i] as any[]).map(String);
                    break;
                }
            }

            // If no smart header found, fallback to row 0
            if (detectedHeaders.length === 0) {
                detectedHeaders = (jsonData[0] as any[]).map(String);
                headerRowIndex = 0;
            }

            const headers = detectedHeaders;

            // GLOBAL STORE CHECK: Do we have a mapping?
            // Note: We are inside a closure, so we use the value from render scope `columnMapping`.
            // If we are processing a queue, `columnMapping` should be available.
            // If this is the FIRST file triggering the modal, `columnMapping` is null.

            if (!columnMapping) {
                // If this is the first file being processed in a batch, it triggers the modal.
                // We should add this file to pending.
                // BUT wait, if we drop 5 files, this reader.onload runs 5 times.
                // The first time, it sets modal open.
                // We need to ensure we don't overwrite pendingFiles, but Append to it.
                setRawHeaders(headers);
                setMappingModalOpen(true);
                setPendingFiles(prev => [...prev, file]);
                console.log("Headers detected at row " + headerRowIndex);
                return;
            }

            // If we DO have a mapping, parse the data
            const parsedTasks: Task[] = [];

            // Convert to objects using the detected header row
            // We slice the data from the header row onwards
            const dataRows = jsonData.slice(headerRowIndex + 1);

            // Map the data rows to objects using the detected headers
            const jsonDataObjects = dataRows.map((row: any) => {
                const obj: any = {};
                headers.forEach((header, index) => {
                    obj[header] = row[index];
                });
                return obj;
            });

            jsonDataObjects.forEach((row: any) => {
                const projectName = sheetName;
                const taskName = row[columnMapping.taskCol];
                const startDate = new Date(row[columnMapping.startCol]);
                const endDate = new Date(row[columnMapping.endCol]);

                if (projectName && taskName) {
                    // --- DATA CLEANING ---
                    // Helper to remove accents: "Gestión" -> "gestion"
                    const normalizeString = (str: string) =>
                        str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

                    const normalizedTaskName = normalizeString(String(taskName));
                    const IGNORED_KEYWORDS = [
                        'gestion de residuos',
                        'seguridad y salud',
                        'contenedores',
                        'epp'
                    ];

                    if (IGNORED_KEYWORDS.some(keyword => normalizedTaskName.includes(keyword))) {
                        return; // Skip this task
                    }

                    // --- MOTOR BLUEPRINT LOGIC ---
                    // 1. Strict Date Validation
                    // User Request: Ignore tasks without Valid Start AND End Date
                    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
                        return;
                    }

                    const validStartDate = startDate;
                    const validEndDate = endDate;

                    // 2. Extra Columns
                    const wbs = columnMapping.wbsCol ? row[columnMapping.wbsCol] : undefined;
                    const type = columnMapping.typeCol ? row[columnMapping.typeCol] : undefined;

                    const slack = columnMapping.slackCol ? parseFloat(row[columnMapping.slackCol]) : undefined;
                    const isMilestone = columnMapping.milestoneCol ? !!row[columnMapping.milestoneCol] : false;

                    // Parse Budget
                    let budget: number | undefined = undefined;
                    if (columnMapping.budgetCol && row[columnMapping.budgetCol]) {
                        const val = row[columnMapping.budgetCol];
                        if (typeof val === 'number') {
                            budget = val;
                        } else if (typeof val === 'string') {
                            // Clean currency symbols and delimiters. Example: "1.234,56 €" -> 1234.56
                            // Or simple accounting: "1,234.56"
                            // Best effort cleaning:
                            const clean = val.replace(/[^0-9.,-]/g, '').replace(',', '.'); // Very naive, assuming dot decimal usually in code context, but Excel raw might vary.
                            // Better approach for Excel parsers: XLSX often gives numbers directly. If string:
                            // If European format (1.000,00), remove dots, replace comma with dot.
                            // If US format (1,000.00), remove commas.

                            // Let's assume standard float parsing usually works if we strip non-numeric but keep dot/comma
                            // For safety in this specific context, let's treat it simple:
                            budget = parseFloat(clean);
                        }
                    }

                    // 3. Delay Calculation (Determinista)
                    // Logic: Today - Fecha Termino (Planned/Effective)
                    // If Today > Termino, it implies delay (positive result).
                    const today = new Date();
                    // We calculate raw difference. 
                    // Using differenceInCalendarDays(later, earlier) returns (later - earlier) in days
                    const delayDays = differenceInCalendarDays(today, validEndDate);

                    // Critical Path Logic: Slack <= 0 OR Milestone OR Explicit Critical
                    const isCritical = (columnMapping.criticalCol && !!row[columnMapping.criticalCol]) ||
                        (slack !== undefined && slack <= 0) ||
                        isMilestone;

                    parsedTasks.push({
                        id: Math.random().toString(36).substr(2, 9),
                        projectId: projectName,
                        projectName: projectName,
                        name: taskName,
                        startDate: validStartDate,
                        endDate: validEndDate,
                        isCritical: isCritical,
                        wbs: wbs ? String(wbs) : undefined,
                        type: type ? String(type) : 'T', // Default to T if missing
                        delayDays: delayDays,
                        totalSlack: slack,
                        isMilestone: isMilestone,
                        budget: budget
                    });
                }
            });

            addTasks(parsedTasks);
        };
        reader.readAsArrayBuffer(file);
    };

    const onDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();

        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            Array.from(e.dataTransfer.files).forEach(processFile);
            e.dataTransfer.clearData();
        }
    }, [columnMapping, addTasks]);

    const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
    };

    return (
        <div
            onClick={() => inputRef.current?.click()}
            onDrop={onDrop}
            onDragOver={onDragOver}
            className={cn(
                "border-2 border-dashed border-muted-foreground/25 rounded-xl p-10 text-center hover:bg-muted/50 transition-colors cursor-pointer flex flex-col items-center gap-4",
            )}
        >
            <input
                type="file"
                className="hidden"
                ref={inputRef}
                multiple
                accept=".xlsx,.xls,.csv"
                onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                        Array.from(e.target.files).forEach(processFile);
                        // Reset input so same file can be selected again if needed
                        e.target.value = '';
                    }
                }}
            />
            <div className="bg-primary/10 p-4 rounded-full">
                <Upload className="h-8 w-8 text-primary" />
            </div>
            <div>
                <h3 className="text-lg font-semibold">Cargar archivos Excel</h3>
                <p className="text-sm text-muted-foreground mt-2">Arrastra o haz clic para seleccionar</p>
                <p className="text-xs text-muted-foreground mt-1">Soporta .xlsx, .xls, .csv</p>
            </div>

            {tasks.length > 0 && (
                <div className="mt-4 flex items-center gap-2 text-green-600 bg-green-50 px-4 py-2 rounded-full text-sm font-medium">
                    <CheckCircle className="h-4 w-4" />
                    {tasks.length} tareas cargadas exitosamente
                </div>
            )}
        </div>
    );
}
