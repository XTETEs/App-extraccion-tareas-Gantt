import { create } from 'zustand';
import type { Task, ColumnMapping, DateRange } from '../types';
import { db } from '../db';

interface AppState {
    tasks: Task[];
    columnMapping: ColumnMapping | null;
    dateRange: DateRange;
    isMappingModalOpen: boolean;
    rawHeaders: string[];
    hiddenProjects: string[];

    // Actions
    setTasks: (tasks: Task[]) => void;
    addTasks: (tasks: Task[]) => Promise<void>;
    setColumnMapping: (mapping: ColumnMapping) => void;
    setDateRange: (range: DateRange) => void;
    setMappingModalOpen: (isOpen: boolean) => void;
    setRawHeaders: (headers: string[]) => void;
    toggleProjectVisibility: (projectId: string) => void;
    reset: () => void;

    // Persistence
    loadFromDB: () => Promise<void>;
    clearData: () => Promise<void>;
    deleteProjects: (projectNames: string[]) => Promise<void>;
}

export const useStore = create<AppState>((set) => ({
    tasks: [],
    columnMapping: null,
    dateRange: { from: undefined, to: undefined },
    isMappingModalOpen: false,
    rawHeaders: [],
    hiddenProjects: [],

    setTasks: (tasks) => {
        set({ tasks });
        // Optional: Replace entire DB content if setTasks is used for bulk replacement
        // For now, assuming addTasks is the primary ingestion
    },

    addTasks: async (newTasks) => {
        // 1. Update State (Optimistic UI)
        set((state) => ({ tasks: [...state.tasks, ...newTasks] }));

        // 2. Persist to DB
        try {
            await db.tasks.bulkAdd(newTasks);

            // Extract distinct projects and save them
            const uniqueProjects = Array.from(new Set(newTasks.map(t => t.projectName)));
            const projectsToSave = uniqueProjects.map(name => ({
                id: name, // Use name as ID since it's the PK in Dexie schema
                name,
                lastUpdated: new Date()
            }));
            // bulkPut overwrites existing keys
            await db.projects.bulkPut(projectsToSave);

        } catch (error) {
            console.error("Failed to persist tasks to DB:", error);
            // Revert state if needed, or just warn
        }
    },

    setColumnMapping: (mapping) => set({ columnMapping: mapping }),
    setDateRange: (range) => set({ dateRange: range }),
    setMappingModalOpen: (isOpen) => set({ isMappingModalOpen: isOpen }),
    setRawHeaders: (headers) => set({ rawHeaders: headers }),

    toggleProjectVisibility: (projectId) => set((state) => ({
        hiddenProjects: state.hiddenProjects.includes(projectId)
            ? state.hiddenProjects.filter(id => id !== projectId)
            : [...state.hiddenProjects, projectId]
    })),

    reset: () => set({ tasks: [], columnMapping: null, rawHeaders: [], hiddenProjects: [] }),

    loadFromDB: async () => {
        try {
            const count = await db.tasks.count();
            if (count > 0) {
                const tasks = await db.tasks.toArray();
                set({ tasks });
            }
        } catch (error) {
            console.error("Failed to load from DB:", error);
        }
    },

    clearData: async () => {
        try {
            await db.tasks.clear();
            await db.projects.clear();
            set({ tasks: [], columnMapping: null, rawHeaders: [], hiddenProjects: [] });
        } catch (error) {
            console.error("Failed to clear DB:", error);
        }
    },

    deleteProjects: async (projectNames) => {
        try {
            // Delete from DB
            await db.tasks.where('projectName').anyOf(projectNames).delete();
            await db.projects.bulkDelete(projectNames);

            // Update State
            set((state) => ({
                tasks: state.tasks.filter(t => !projectNames.includes(t.projectName)),
                hiddenProjects: state.hiddenProjects.filter(id => !projectNames.includes(id))
            }));
        } catch (error) {
            console.error("Failed to delete projects:", error);
        }
    }
}));

