import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}
// Deterministic color generator from string (HSL)
export function stringToColor(str: string, saturation = 65, lightness = 50) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const h = Math.abs(hash) % 360;
    return `hsl(${h}, ${saturation}%, ${lightness}%)`;
}

// Hierarchy Filter: Only return Leaf Tasks
export function getLeafTasks(allTasks: any[]) {
    // 1. Sort by WBS (Lexical) to ensure Hierarchy
    const sorted = [...allTasks].sort((a, b) => {
        if (a.projectName !== b.projectName) return a.projectName.localeCompare(b.projectName);
        const wbsA = a.wbs ? a.wbs.toString().trim() : '';
        const wbsB = b.wbs ? b.wbs.toString().trim() : '';
        return wbsA.localeCompare(wbsB);
    });

    const leafTasks: any[] = [];

    for (let i = 0; i < sorted.length; i++) {
        const current = sorted[i];

        // Special case: If no WBS, treat as leaf (fallback)
        if (!current.wbs) {
            leafTasks.push(current);
            continue;
        }

        const next = sorted[i + 1];
        let isParent = false;

        // Check if current WBS is parent of next
        if (next && next.projectName === current.projectName && next.wbs) {
            const currWbs = current.wbs.toString().trim();
            const nextWbs = next.wbs.toString().trim();

            // Logic: 1. Dot/Dash separator or 2. Strict Prefix
            if (nextWbs.startsWith(currWbs + '.') || nextWbs.startsWith(currWbs + '-') || (nextWbs.startsWith(currWbs) && nextWbs.length > currWbs.length)) {
                isParent = true;
            }
        }

        if (!isParent) {
            leafTasks.push(current);
        }
    }
    return leafTasks;
}
